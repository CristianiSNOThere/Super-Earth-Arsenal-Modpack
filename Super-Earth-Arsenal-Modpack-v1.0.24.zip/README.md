# Super Earth Arsenal Mod Pack v1.0.24

This ZIP includes the twenty listed mods. SG-8P Punisher Plasma is omitted and remains at its stock behavior. Loyalist and One-Two are also no longer repurposed by Punisher Plasma.

The AR-32 Pacifier deals 75 normal and 15 durable damage, builds Stun Medium at strength 3 per hit, has a 65-round default magazine, and has 0.6 sway.

[Download v1.0.24](https://github.com/CristianiSNOThere/Super-Earth-Arsenal-Modpack/releases/download/v1.0.24/Super-Earth-Arsenal-Modpack-v1.0.24.zip) | [Choose individual mods](https://github.com/CristianiSNOThere/Super-Earth-Arsenal-Pack)

## Gameplay changes

| Mod | Gameplay settings |
|---|---|
| VG-70 Variable | Keeps its primary slot, mobile reload and backpack-free operation. Magazine capacity becomes 150 rounds. Auto offers 550, 750 and 1,000 RPM at 110/29, 90/24 and 75/20 normal/durable damage per bullet, AP3. Volley fires 15 simultaneous bullets at 40/11 each, AP3, following the selected 550, 750 or 1,000 RPM rate. Total fires all remaining rounds at 28/8 per bullet, AP4, with 0.75 spread on both axes. Spare-magazine settings remain 6 starting, 7 maximum and 7 per resupply. Base ergonomics becomes 40 and sway becomes 0.9. Recoil falls 15% in every mode: horizontal/vertical drift 5/10 becomes 4.25/8.5, and climb 4/8 becomes 3.4/6.8. Total retains its stock right-arm self-injury and knockdown behavior. Sustained Auto muzzle flashes stay aligned. Reload timing, projectile speed and sounds are retained. |
| PLAS-45 Epoch | PLAS-45 Epoch highest-charge shots gain 30% more normal and durable direct-hit and blast damage, burning on blast hits, a 5 m full-damage radius, 6 m outer damage radius and 7 m shockwave radius. Magazine capacity increases from 3 to 4 rounds and maximum spare magazines from 4 to 5. Reload while walking with the existing reload animation. Base highest-tier direct damage is 520/260 and blast damage is 1040/1040, with its existing charge multiplier retained. Charge times remain 1.0/2.5/2.6 seconds and lower-charge shots retain their current values. Starting/resupply spare magazines remain 2/2. |
| AR-32 Pacifier | Bullets deal 75 normal and 15 durable damage, up from 55/10, and build Stun Medium at strength 3 per hit, up from 2. Its default magazine holds 65 rounds, up from 40, and weapon sway falls from 1 to 0.6. |
| AC-8 Autocannon | The call-in supplies only the weapon, freeing the backpack slot. The gun carries 10 loaded + 60 reserve rounds and uses its familiar five-round top reload while walking, about 20% faster than stock. A resupply is set to refill up to 60 reserve rounds. Ergonomics rises from 17 to 30. Horizontal/vertical recoil drift falls from 200/450 to 150/337.5 and recoil climb from 2/100 to 1.5/75, a 25% reduction to each. APHET direct damage becomes 375 normal / 340 durable with AP5, and impact blast becomes 180 normal. FLAK explosion damage becomes 210 normal with an 8 m outer radius; FLAK direct damage and shrapnel are unchanged. JAR-5 Dominator High Explosive ammo shares that explosion and receives the same explosion buff. |
| PLAS-1 Scorcher AR | Increases the magazine from 20 to 50 rounds and fire rate from 350 to 540 RPM. Reduces normal damage from 200 total to 150: 75 impact plus 75 explosion, before armor, hit location and distance falloff. Sets impact durable damage to 38 and explosion durable damage to 75 (113 combined against fully durable targets). Increases the full-damage blast radius from 1 to 1.25 metres and outer blast radius from 2 to 2.5 metres. Starting spare magazines increase from 3 to 4, and maximum spare magazines from 5 to 6; resupply grants 5 magazines. Uses the Scorcher's native Semi and Auto selector. Select Auto in Weapon Functions for continuous fire; at 540 RPM, a 50-round magazine provides approximately 5.56 seconds of sustained fire. Reduces horizontal/vertical recoil drift from 20 to 15, horizontal camera recoil from 2 to 1.5, and vertical camera recoil from 20 to 15 (25% less per shot). |
| One True Flag | Default damage is 300 normal / 150 durable. For selectable damage from 0 to 9999 and half/equal durable damage, use the individual One True Flag package. |
| SAI Focus Precision | LAS-12 SAI deals 90 normal and 21 durable damage at the muzzle with either lens. Standard Lens spread is 70 MRAD and Focus Lens spread is 37.5 MRAD on both axes, each 50% below stock. Both lenses fire at 900 RPM. Projectile launch speed is 1,300 m/s and drag is 1.244, adding damage loss over distance. Recoil is reduced by one-third with both lenses. Heat per shot is reduced by one-third: 2 to 1.333333 with Standard and cooldown heatsinks, or 1.5 to 1 with the heat-capacity heatsink. |
| AR-11 Arbitrator | Sets rifle damage to 80 and magazine capacity to 65 rounds. Sets underbarrel starting and maximum spare ammo to 30, stagger force to 25, and push force to 20. Its shotgun magazine holds 4 shells and refills 20 shells. Base ergonomics is 41, giving 40 with the default optic. |
| R/40-K Hot-Shot | Sets magazine capacity to 20 rounds, starting magazines to 5, resupply magazines to 5, maximum magazines to 5, and ergonomics to 45. Uses standard magazine reloads. |
| Gas Overhaul | Adds 15-second temporary armor reduction to supported gas weapons, including Dog Breath and gas grenades. Shared gas normal/durable damage rises from 25/25 to 45/45 DPS; Sterilizer magazine capacity from 125 to 175, gas/confusion buildup from 0.5 to 0.75, and incoming Helldiver gas multiplier from 1.3 to 0.7333. Shared Acid Storm duration changes from 1 to 15 seconds. |
| ARC-3 Rapid/Supercharge | Adds the native Auto/Rapid and Semi/Supercharge fire-mode selector. Rapid charges in 0.307692/0.338462/0.369231 seconds and uses 0.85x of the shared 226/90 normal/durable pulse damage (about 192.1/76.5 before armor and hit location). Supercharge charges in 3.4/3.5/3.75 seconds, uses 2325/2325 damage and AP7, targets one enemy (chain 1, split 0), and cannot explode from overcharge. Both modes keep stock ARC audio and 45 m reach. |
| ARC-12 Blitzer | Sets normal damage to 100, durable damage to 45, arc range to 30 m, and fire rate to 80 RPM. |
| CQC-20 Breaching Hammer | Sets direct-hit, slight-blast, and large-blast armor penetration to 7. Sets starting, resupply, and maximum magazine counts to 21 each. |
| PLAS-39 Accelerator Rifle | Sets magazine capacity to 21, horizontal/vertical drift and camera recoil to 2, horizontal/vertical spread to 0.3, sway to 0.4, stagger to 25, direct-hit and blast armor penetration to 4, and outer blast/shockwave values to 2.5. Offers near-instant Semi fire at a base rate of 200 RPM and charged three-round Burst with normal firing audio. |
| P-34 Breacher | Sets the magazines received from resupply to 2. |
| S-11 Speargun | Sets starting magazines to 16, resupply magazines to 10, maximum magazines to 20, and ergonomics to 40. |
| APW-1 Anti-Materiel Rifle | Sets ergonomics to 40. |
| 40-K Meltagun | Sets ergonomics to 40. |
| A/GM-17 Gas Mortar Sentry | Sets sentry health to 600. |
| RS-422 Railgun | Sets durable damage to 240. |

## Install

If your currently installed pack includes Punisher Plasma, equip a different primary while that pack is still installed. Close the game completely before replacing it. Import this ZIP into Arsenal, enable its single option, keep Bingus Shared Loader at its documented priority, Purge and Deploy, then restart the game. Requires Helldivers 2 Steam build 25480438 and Bingus Shared Loader v19. Disable other Super Earth Arsenal modpacks and the individual versions of these mods to avoid duplicate resources.

For AC-8, choose APHET or FLAK through the stock Weapon Functions selector. For ARC-3, hold R and choose Auto/Rapid or Semi/Supercharge. For PLAS-39, hold R and use the left-side Weapon Functions selector. Semi fires one round with a 0.01-second minimum charge and a base 0.30-second interval; the native fire-rate modifier can increase that interval to approximately 0.333 seconds. Burst fires three rounds spaced 0.12 seconds apart with a 0.45-second minimum charge, consuming three rounds. Both modes retain normal firing audio and the game's fire-rate modifier.

## Changes in v1.0.23

Adds the VG-70 Variable portable Maxigun rework. The pack includes 20 mods; Pacifier remains included and Punisher Plasma remains omitted.
