Super Earth Arsenal Mod Pack v1.0.15 - 18 mods.

The AC-8 call-in delivers the Autocannon without its ammunition backpack. It carries 10 loaded rounds and 60 reserve rounds, reloads itself with its familiar five-round top clips while walking, and reloads about 20% faster. The authored resupply amount is 60 reserve rounds. APHET direct damage rises to 375 normal / 340 durable with AP5, and its impact blast rises to 180 normal damage. FLAK explosion damage rises to 210 normal and its outer radius to 8 m; FLAK direct damage and shrapnel remain unchanged. The FLAK explosion is shared with JAR-5 Dominator High Explosive ammunition, which also receives the explosion damage/radius change.

Use this pack or the individual packages, not both. Requires Bingus Shared Loader v19 and the supported game build.
