SUPER-EARTH ARSENAL PACK - COMPLETE

One local Arsenal package containing the six current Super-Earth Arsenal mods and the nine supported SHODAN Preset 1 weapon/sentry profiles.

SUPPORTED BUILD AND LOADER

- Helldivers 2 Steam build 25480438.
- Bingus Shared Loader v18 or newer.
- The included Sterilizer is local v0.8, which recognizes ARC-3 v0.9 before validating the shared damage table. It replaces the released v0.7 resource and has not been published.

CONTENTS

| Existing Arsenal mod | Version |
|---|---:|
| One True Flag | v0.9 |
| SAI Focus Precision | v0.4 |
| AR-11 Arbitrator Tuned | v0.2 |
| R/40-K Hot-Shot Magazine Tuning | v0.8 |
| TX-41 Sterilizer Armor Control | local v0.8 |
| ARC-3 Rapid Arc Thrower | v0.9 |

| SHODAN Preset 1 profile | Fields |
|---|---:|
| ARC-12 Blitzer | 4 |
| CQC-20 Breaching Hammer | 6 |
| PLAS-39 Accelerator Rifle | 14 |
| P-34 Breacher | 1 |
| S-11 Speargun | 4 |
| APW-1 Anti-Materiel Rifle | 1 |
| 40-K Meltagun | 1 |
| A/GM-17 Gas Mortar Sentry | 1 |
| RS-422 Railgun | 1 |

The Commando cooldown was held back because this build has no exact StratagemSettings source/stock record to validate it safely.

LAUNCH COMPATIBILITY

- The preset runtime waits 30 seconds for the installed package modules, then requires One True Flag, SAI, AR-11, Sterilizer, and ARC-3 to report Applied. It allows up to two more minutes. If a required patch is missing or fails, none of the preset values are written.
- Once those checksum-based modules are active, each preset entity is preflighted and applied as its own transaction. If one profile conflicts, other profiles can still apply safely.
- R/40-K has no shared-table dependency with the preset profiles and keeps its existing independent behavior.

CHOOSING THE FULL PACK OR INDIVIDUAL MODS

- For everything in one selection, import this ZIP and enable its single option.
- For a custom selection, get the six individual Arsenal packages from the [GitHub releases](https://github.com/CristianiSNOThere/Super-Earth-Arsenal-Pack/releases) and import only the SHODAN profile ZIPs you want from `SHODAN-Preset-01-Mods-README.md` alongside this package in the local outputs folder.
- When selecting both Sterilizer and ARC-3 individually, use the separate local [TX-41 Sterilizer v0.8 ZIP](TX-41-Sterilizer-Armor-Control-v0.8.zip) in place of the published v0.7 ZIP. v0.8 is the version that recognizes ARC-3 v0.9's known table edits.
- Choose either this complete ZIP or the individual package set. Do not enable the complete pack alongside its individual counterparts, since that duplicates addon resources.
- If using individual SHODAN profiles with other installed Arsenal mods, they wait for any detected Flag, SAI, AR-11, Sterilizer, or ARC-3 module to report Applied before making changes.

INSTALL

Import the ZIP into Arsenal, enable the complete-pack option, Purge and Deploy, then restart the game. Allow the launch initialization to finish and check the loader/mod logs for the Applied statuses. The SHODAN profile logs report each entity separately.

This is a local build for review. It has not been imported, deployed, or published.
