local native = {}
local OWNER = '5e7f47af911f0630'
local GUARDS = {{rva=5281136,bytes='4885c97471488b051c2af602448bc14c8b90d82bf10048b8379f711660f3196748f7e1488bc1482bc248d1e84803c248'},{rva=5262720,bytes='4885c9746c488b050c72f602448bc14c8b90d82af10048b8cdcccccccccccccc48f7e148c1ea048d0492c1e002442bc0'},{rva=7694280,bytes='8bc8498b4260488d14498b049048'},{rva=7592314,bytes='498bcde83e79dcff488bf88b88bc00000083f901762e418b44ee143bc173208b8fc000000041894cee188d480141894cee14eb103bc87582438b44c304eb80418974ee14418b4508'},{rva=7695008,bytes='443ba88c0000000f92c04883c420415e415d'},{rva=5327888,bytes='4885c97471488b057c73f502448bc14c8b90802ef10048b8fb99d3e0ce8bd4f148f7e148c1ea0969c21e020000442bc0'},{rva=5329152,bytes='4883ec284c8bd14885c9750733c04883c428c38b41083b0508ebf6020f84a30000004c8b1daf15e1024533c048895c24'},{rva=6376742,bytes='8b45a80f57ffffc8f20f5af8a9fdffffff0f84c0000000'},{rva=6376525,bytes='4180b8ed000000000f84f5030000'}}
local function unhex(s) return (s:gsub('..', function(p) return string.char(tonumber(p,16)) end)) end
OWNER = unhex(OWNER)
local function u32(s,o)
    assert(s and o >= 0 and o+4 <= #s, 'Native field unreadable')
    local a,b,c,d=s:byte(o+1,o+4)
    return a+b*256+c*65536+d*16777216
end
local function read(api,p,n) return assert(api.read(p,n), 'Native data unavailable') end
local function pointer(api,s,o) return assert(api.pointer(s,o), 'Native pointer unavailable') end
local function lookup(api,h,o,key)
    local cap,empty,mult=u32(h,o+8),u32(h,o+12),u32(h,o+16)
    assert(cap <= 4096 and (cap == 0 or bit.band(cap,cap-1) == 0), 'Native map capacity changed')
    if cap == 0 then return nil end
    local array=pointer(api,h,o)
    -- Split multiplication to preserve exact 32-bit wraparound in Lua numbers.
    local product=((key%65536)*mult + math.floor(key/65536)*(mult%65536)*65536)%4294967296
    for probe=0,math.min(cap,64)-1 do
        local row=read(api,array+bit.band(product+probe,cap-1)*8,8)
        local identity,index=u32(row,0),u32(row,4)
        if identity == key then return index ~= 4294967295 and index or nil end
        if identity == empty then return nil end
    end
    error('Native map probe bound reached')
end

function native.prepare(api)
    local game=api.byte_pointer(api.module('game.dll'))
    for _,g in ipairs(GUARDS) do
        local bytes=unhex(g.bytes)
        assert(read(api,game+g.rva,#bytes)==bytes,'Unsupported native weapon code; no edit applied')
    end
    local owner=pointer(api,read(api,game+0x346bf98,8),0)
    local weapon_map=pointer(api,read(api,owner+0xf12bd8,8),0)
    local charge_map=pointer(api,read(api,owner+0xf12ad8,8),0)
    local projectile_map=pointer(api,read(api,owner+0xf12e80,8),0)
    local mapping=read(api,projectile_map+290*16,16)
    assert(mapping:sub(1,8)==OWNER and u32(mapping,8)==136,'Projectile resource owner/index changed')
    return { game=game, owner=owner, weapon_group=weapon_map-28, charge_group=charge_map-28,
        projectile_map=projectile_map, projectile_address=projectile_map+542*16+136*616 }
end

function native.instances(api,plan)
    assert(api.pointer(read(api,plan.native.game+0x346bf98,8),0)==plan.native.owner,
        'Native entity tables changed; restart required')
    assert(api.pointer(read(api,plan.native.owner+0xf12bd8,8),0)==plan.native.weapon_group+28
        and api.pointer(read(api,plan.native.owner+0xf12ad8,8),0)==plan.native.charge_group+28,
        'Native component tables changed; restart required')
    local manager=pointer(api,read(api,plan.native.game+0x3326ce0,8),0)
    local h=read(api,manager,192)
    local count=u32(h,0x1c)
    assert(count <= 512 and count <= u32(h,0x10), 'Native weapon instance count changed')
    if count == 0 then return {} end
    local array=pointer(api,h,0x48)
    local modes=pointer(api,h,0x60)
    local references=read(api,array,count*8)
    local charge_manager=pointer(api,read(api,plan.native.game+0x3326c20,8),0)
    local ch=read(api,charge_manager,160)
    local projectile_manager=pointer(api,read(api,plan.native.game+0x33266d8,8),0)
    local ph=read(api,projectile_manager,224)
    assert(pointer(api,read(api,plan.native.owner+0xf12e80,8),0)==plan.native.projectile_map,
        'Native projectile table changed')
    local result={}
    for i=0,count-1 do
        local entity=pointer(api,references,i*8)
        local identity=read(api,entity,24)
        if identity:sub(1,8)==OWNER and bit.band(u32(identity,20),1)==1 then
            local id=u32(identity,8)
            assert(lookup(api,h,0x30,id)==i,'Native weapon slot changed')
            local mode_address=modes+i*12
            local mode=u32(read(api,mode_address,4),0)
            if mode==2 or mode==3 then
                local weapon=plan.weapon_address
                local wi=lookup(api,h,0x70,id)
                if wi then
                    assert(wi < u32(h,0xa8),'Native weapon settings index changed')
                    weapon=pointer(api,h,0xb0)+wi*1232
                end
                local charge=plan.charge_address
                local ci=lookup(api,ch,0x50,id)
                if ci then
                    assert(ci < u32(ch,0x88),'Native charge settings index changed')
                    charge=pointer(api,ch,0x90)+ci*216
                end
                local projectile=plan.projectile_address
                local pi=lookup(api,ph,0x90,id)
                if pi then
                    assert(pi < 512,'Native projectile settings index changed')
                    projectile=pointer(api,ph,0xd0)+pi*616
                end
                local charge_state
                local si=lookup(api,ch,0x20,id)
                if si then
                    assert(si < u32(ch,0xc),'Native charge state index changed')
                    assert(read(api,pointer(api,ch,0x38)+si*8,8)==references:sub(i*8+1,i*8+8),
                        'Native charge instance owner changed')
                    charge_state=pointer(api,ch,0x40)+si*40
                end
                result[#result+1]={ id=id, mode=mode, mode_address=mode_address,
                    entity=entity, identity=identity, weapon=weapon, charge=charge,
                    charge_state=charge_state, projectile=projectile }
            end
        end
    end
    -- A game update may swap arrays; reject stale snapshots before any writes.
    assert(read(api,manager+0x48,8)==h:sub(0x49,0x50)
        and read(api,manager+0x60,8)==h:sub(0x61,0x68),'Native weapon arrays changed')
    return result
end

return native
